
Pode pegar templates do HTML pras páginas -> CSS pronto

https://pingendo.com/
https://startbootstrap.com/previews/freelancer/




VISUAL GUIDELINE

Links de Fontes utilizáveis: COMICS
https://www.dafont.com/pt/heroes-legend.font
https://www.dafont.com/pt/space-comics.font
https://www.dafont.com/pt/avengeance-mightiest-avenger.font
https://www.dafont.com/pt/kids-magazine.font
https://www.dafont.com/pt/engcomica.font
https://www.dafont.com/pt/vtc-supermarket-sale.font
https://www.dafont.com/pt/conversation-2.font ESCOLHIDA PARA TITULO NO NOME DO JOGO
https://www.dafont.com/pt/batman-forever.font
https://www.dafont.com/pt/batman2.font
https://www.dafont.com/pt/adventure.font
https://www.dafont.com/pt/outrun-future.font

Links de Fontes utilizáveis: BASIC SAN-SERIF
https://www.dafont.com/pt/the-bold-font.font?text=Super+hero+cards&back=theme
https://www.dafont.com/pt/beckman.font?text=sobre&back=theme 
Fonte para textos padrões no site:
https://www.dafont.com/pt/biko.font?text=Em+um+certo+Deus+veio+e+lhe+disse%3A+filho%2C+venha+c%E1&psize=s&back=theme



Cores:
NavegationBar - #c8301e com gradiente variante

Content - NO CSS
background: rgb(0,0,0);
background: linear-gradient(90deg, rgba(0,0,0,1) 0%, rgba(2,6,106,1) 5%, rgba(0,2,198,1) 15%, rgba(10,0,166,1) 50%, rgba(0,2,198,1) 85%, rgba(2,6,106,1) 95%, rgba(0,0,0,1) 100%);

background: rgb(0,0,0);
background: linear-gradient(90deg, rgba(0,0,0,1) 0%, rgba(2,8,143,1) 1%, rgba(0,2,198,1) 15%, rgba(10,0,166,1) 50%, rgba(0,2,198,1) 85%, rgba(2,8,143,1) 99%, rgba(0,0,0,1) 100%);
